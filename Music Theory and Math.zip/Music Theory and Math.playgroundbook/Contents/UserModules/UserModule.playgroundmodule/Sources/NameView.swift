import SwiftUI
import PlaygroundSupport

struct NameView: View {
    var body: some View {
        VStack {
            Text("May I please learn your name?")
                .bold()
                .frame(alignment: .center)
                .multilineTextAlignment(.center)
            NavigationLink(destination: NameView()) {
                Text("Continue")
            }
        }
    }
}
