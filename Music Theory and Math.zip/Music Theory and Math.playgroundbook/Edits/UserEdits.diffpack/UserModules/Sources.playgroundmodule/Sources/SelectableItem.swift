import SwiftUI

struct SelectableItem: View {
    @Environment(\.colorScheme) var colorScheme
    var title: String
    var selected: Bool
    var action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(.system(size: 14))
                    .foregroundColor(selected ? (colorScheme == .dark ? Color.white : Color.black) : Color.gray)
                Spacer().frame(width: 2)
                if selected {
                    Image(systemName: "checkmark")
                        .resizable()
                        .frame(width: 10, height: 10)
                }
                else {
                    Spacer().frame(width: 10, height: 10)
                }
            }
        }
    }
}
