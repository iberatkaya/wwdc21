import SwiftUI

public class Store: ObservableObject {
    //Make the class public.
    public init(){}
}
