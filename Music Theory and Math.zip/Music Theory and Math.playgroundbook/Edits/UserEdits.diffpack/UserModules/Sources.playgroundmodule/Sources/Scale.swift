import SwiftUI
import UIKit

public let scaleTypes = ["Major", "Minor"]

public class Scale: ObservableObject, Identifiable, Equatable {
    public let id = UUID()
    public init(image: UIImage, label: String, scaleType: String, key: String, formula: [Int]){
        self.image = image
        self.label = label
        self.scaleType = scaleType
        self.key = key
        self.formula = formula
    }
    
    public static func == (lhs: Scale, rhs: Scale) -> Bool {
        return lhs.label == rhs.label
    }
    
    @Published var image: UIImage
    @Published var label: String
    @Published var scaleType: String
    @Published var key: String
    @Published var formula: [Int]
}

let scaleImages: [UIImage] = []

public struct GuitarScales {
    static let majorFormula = [2, 2, 1, 2, 2, 2]
    static let minorFormula = [2, 1, 2, 2, 1, 2]
    
    public static let scales = [
        aMajor,
        aMinor,
        aSMajor, 
        aSMinor,
        bMajor,
        bMinor,
        cMajor,
        cMinor,
        cSMajor, 
        cSMinor,
        dMajor,
        dMinor,
        dSMajor,
        dSMinor,
        eMajor,
        eMinor,
        fMajor,
        fMinor,
        fSMajor,
        fSMinor,
        gMajor,
        gMinor,
        gSMajor,
        gSMinor
    ]
    public static let aMajor = Scale(image: #imageLiteral(resourceName: "a_major_guitar.jpg"), label: "A Major", scaleType: scaleTypes[0], key: "A", formula: majorFormula)
    public static let aMinor = Scale(image: #imageLiteral(resourceName: "a_natural_minor_guitar.jpg"), label: "A Minor", scaleType: scaleTypes[1], key: "A", formula: minorFormula)
    public static let aSMajor = Scale(image: #imageLiteral(resourceName: "a_sharp_major_guitar.jpg"), label: "A# Major", scaleType: scaleTypes[0], key: "A#", formula: majorFormula)
    public static let aSMinor = Scale(image: #imageLiteral(resourceName: "a_sharp_natural_minor_guitar.jpg"), label: "A# Minor", scaleType: scaleTypes[1], key: "A#", formula: minorFormula)
    public static let bMajor = Scale(image: #imageLiteral(resourceName: "b_major_guitar.jpg"), label: "B Major", scaleType: scaleTypes[0], key: "B", formula: majorFormula)
    public static let bMinor = Scale(image: #imageLiteral(resourceName: "b_natural_minor_guitar.jpg"), label: "B Minor", scaleType: scaleTypes[1], key: "B", formula: minorFormula)
    public static let cMajor = Scale(image: #imageLiteral(resourceName: "c_major_guitar.jpg"), label: "C Major", scaleType: scaleTypes[0], key: "C", formula: majorFormula)
    public static let cMinor = Scale(image: #imageLiteral(resourceName: "c_natural_minor_guitar.jpg"), label: "C Minor", scaleType: scaleTypes[1], key: "C", formula: minorFormula)
    public static let cSMajor = Scale(image: #imageLiteral(resourceName: "c_sharp_major_guitar.jpg"), label: "C# Major", scaleType: scaleTypes[0], key: "C#", formula: majorFormula)
    public static let cSMinor = Scale(image: #imageLiteral(resourceName: "c_sharp_natural_minor_guitar.jpg"), label: "C# Minor", scaleType: scaleTypes[1], key: "C#", formula: minorFormula)
    public static let dMajor = Scale(image: #imageLiteral(resourceName: "d_major_guitar.jpg"), label: "D Major", scaleType: scaleTypes[0], key: "D", formula: majorFormula)
    public static let dMinor = Scale(image: #imageLiteral(resourceName: "d_natural_minor_guitar.jpg"), label: "D Minor", scaleType: scaleTypes[1], key: "D", formula: minorFormula)
    public static let dSMajor = Scale(image: #imageLiteral(resourceName: "d_sharp_major_guitar.jpg"), label: "D# Major", scaleType: scaleTypes[0], key: "D#", formula: majorFormula)
    public static let dSMinor = Scale(image: #imageLiteral(resourceName: "d_sharp_natural_minor_guitar.jpg"), label: "D# Minor", scaleType: scaleTypes[1], key: "D#", formula: minorFormula)
    public static let eMajor = Scale(image: #imageLiteral(resourceName: "e_major_guitar.jpg"), label: "E Major", scaleType: scaleTypes[0], key: "E", formula: majorFormula)
    public static let eMinor = Scale(image: #imageLiteral(resourceName: "e_natural_minor_guitar.jpg"), label: "E Minor", scaleType: scaleTypes[1], key: "E", formula: minorFormula)
    public static let fMajor = Scale(image: #imageLiteral(resourceName: "f_major_guitar.jpg"), label: "F Major", scaleType: scaleTypes[0], key: "F", formula: majorFormula)
    public static let fMinor = Scale(image: #imageLiteral(resourceName: "f_natural_minor_guitar.jpg"), label: "F Minor", scaleType: scaleTypes[1], key: "F", formula: minorFormula)
    public static let fSMajor = Scale(image: #imageLiteral(resourceName: "f_sharp_major_guitar.jpg"), label: "F# Major", scaleType: scaleTypes[0], key: "F#", formula: majorFormula)
    public static let fSMinor = Scale(image: #imageLiteral(resourceName: "f_sharp_natural_minor_guitar.jpg"), label: "F# Minor", scaleType: scaleTypes[1], key: "F#", formula: minorFormula)
    public static let gMajor = Scale(image: #imageLiteral(resourceName: "g_major_guitar.jpg"), label: "G Major", scaleType: scaleTypes[0], key: "G", formula: majorFormula)
    public static let gMinor = Scale(image: #imageLiteral(resourceName: "g_natural_minor_guitar.jpg"), label: "G Minor", scaleType: scaleTypes[1], key: "G", formula: minorFormula)
    public static let gSMajor = Scale(image: #imageLiteral(resourceName: "g_sharp_major_guitar.jpg"), label: "G# Major", scaleType: scaleTypes[0], key: "G#", formula: majorFormula)
    public static let gSMinor = Scale(image: #imageLiteral(resourceName: "g_sharp_natural_minor_guitar.jpg"), label: "G# Minor", scaleType: scaleTypes[1], key: "G#", formula: minorFormula)
} 


public struct PianoScales {
    static let majorFormula = [2, 2, 1, 2, 2, 2]
    static let minorFormula = [2, 1, 2, 2, 1, 2]
    
    public static let scales = [
        aMajor,
        aMinor,
        aSMajor, 
        aSMinor,
        bMajor,
        bMinor,
        cMajor,
        cMinor,
        cSMajor, 
        cSMinor,
        dMajor,
        dMinor,
        dSMajor,
        dSMinor,
        eMajor,
        eMinor,
        fMajor,
        fMinor,
        fSMajor,
        fSMinor,
        gMajor,
        gMinor,
        gSMajor,
        gSMinor
    ]
    public static let aMajor = Scale(image: #imageLiteral(resourceName: "a_major_piano.jpg"), label: "A Major", scaleType: scaleTypes[0], key: "A", formula: majorFormula)
    public static let aMinor = Scale(image: #imageLiteral(resourceName: "a_natural_minor_piano.jpg"), label: "A Minor", scaleType: scaleTypes[1], key: "A", formula: minorFormula)
    public static let aSMajor = Scale(image: #imageLiteral(resourceName: "a_sharp_major_piano.jpg"), label: "A# Major", scaleType: scaleTypes[0], key: "A#", formula: majorFormula)
    public static let aSMinor = Scale(image: #imageLiteral(resourceName: "a_sharp_natural_minor_piano.jpg"), label: "A# Minor", scaleType: scaleTypes[1], key: "A#", formula: minorFormula)
    public static let bMajor = Scale(image: #imageLiteral(resourceName: "b_major_piano.jpg"), label: "B Major", scaleType: scaleTypes[0], key: "B", formula: majorFormula)
    public static let bMinor = Scale(image: #imageLiteral(resourceName: "b_natural_minor_piano.jpg"), label: "B Minor", scaleType: scaleTypes[1], key: "B", formula: minorFormula)
    public static let cMajor = Scale(image: #imageLiteral(resourceName: "c_major_piano.jpg"), label: "C Major", scaleType: scaleTypes[0], key: "C", formula: majorFormula)
    public static let cMinor = Scale(image: #imageLiteral(resourceName: "c_natural_minor_piano.jpg"), label: "C Minor", scaleType: scaleTypes[1], key: "C", formula: minorFormula)
    public static let cSMajor = Scale(image: #imageLiteral(resourceName: "c_sharp_major_piano.jpg"), label: "C# Major", scaleType: scaleTypes[0], key: "C#", formula: majorFormula)
    public static let cSMinor = Scale(image: #imageLiteral(resourceName: "c_sharp_natural_minor_piano.jpg"), label: "C# Minor", scaleType: scaleTypes[1], key: "C#", formula: minorFormula)
    public static let dMajor = Scale(image: #imageLiteral(resourceName: "d_major_piano.jpg"), label: "D Major", scaleType: scaleTypes[0], key: "D", formula: majorFormula)
    public static let dMinor = Scale(image: #imageLiteral(resourceName: "d_natural_minor_piano.jpg"), label: "D Minor", scaleType: scaleTypes[1], key: "D", formula: minorFormula)
    public static let dSMajor = Scale(image: #imageLiteral(resourceName: "d_sharp_major_piano.jpg"), label: "D# Major", scaleType: scaleTypes[0], key: "D#", formula: majorFormula)
    public static let dSMinor = Scale(image: #imageLiteral(resourceName: "d_sharp_natural_minor_piano.jpg"), label: "D# Minor", scaleType: scaleTypes[1], key: "D#", formula: minorFormula)
    public static let eMajor = Scale(image: #imageLiteral(resourceName: "e_major_piano.jpg"), label: "E Major", scaleType: scaleTypes[0], key: "E", formula: majorFormula)
    public static let eMinor = Scale(image: #imageLiteral(resourceName: "e_natural_minor_piano.jpg"), label: "E Minor", scaleType: scaleTypes[1], key: "E", formula: minorFormula)
    public static let fMajor = Scale(image: #imageLiteral(resourceName: "f_major_piano.jpg"), label: "F Major", scaleType: scaleTypes[0], key: "F", formula: majorFormula)
    public static let fMinor = Scale(image: #imageLiteral(resourceName: "f_natural_minor_piano.jpg"), label: "F Minor", scaleType: scaleTypes[1], key: "F", formula: minorFormula)
    public static let fSMajor = Scale(image: #imageLiteral(resourceName: "f_sharp_major_piano.jpg"), label: "F# Major", scaleType: scaleTypes[0], key: "F#", formula: majorFormula)
    public static let fSMinor = Scale(image: #imageLiteral(resourceName: "f_sharp_natural_minor_piano.jpg"), label: "F# Minor", scaleType: scaleTypes[1], key: "F#", formula: minorFormula)
    public static let gMajor = Scale(image: #imageLiteral(resourceName: "g_major_piano.jpg"), label: "G Major", scaleType: scaleTypes[0], key: "G", formula: majorFormula)
    public static let gMinor = Scale(image: #imageLiteral(resourceName: "g_natural_minor_piano.jpg"), label: "G Minor", scaleType: scaleTypes[1], key: "G", formula: minorFormula)
    public static let gSMajor = Scale(image: #imageLiteral(resourceName: "g_sharp_major_piano.jpg"), label: "G# Major", scaleType: scaleTypes[0], key: "G#", formula: majorFormula)
    public static let gSMinor = Scale(image: #imageLiteral(resourceName: "g_sharp_natural_minor_piano.jpg"), label: "G# Minor", scaleType: scaleTypes[1], key: "G#", formula: minorFormula)
} 
