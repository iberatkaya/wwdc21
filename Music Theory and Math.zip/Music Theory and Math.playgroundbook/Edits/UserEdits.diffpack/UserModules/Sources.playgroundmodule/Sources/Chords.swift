


import SwiftUI

public struct ChordsView: View {
    //Make the struct public.
    public init (){}
    
    @State var incorrectAnswer = false
    @State var chordKey: String = GuitarChords.chords[0].key
    @State var chordType: String = GuitarChords.chords[0].chordType
    
    @State var answers = notes.map({ _ in false })
    
    @State var nums = ["1", "3", "5"];
    
    @State var chordNotes = ["A", "C#", "E"]
    
    @State var instruments = ["Guitar", "Piano"]
    
    @State var buttonClicks = 0
    
    @State var instrument = "Guitar"
    
    @State var randomChord = GuitarChords.chords[Int.random(in: 0..<GuitarChords.chords.count)]
    
    let transition = AnyTransition.opacity.animation(.easeInOut(duration: 0.5))
    
    func setAnswer(index: Int) {
        answers[index] = !answers[index]
        var trueCount = 0
        for i in 0..<answers.count {
            if answers[i] {
                trueCount += 1
            }
        }
        if trueCount > 3 {
            for i in 0..<answers.count {
                if answers[i] {
                    answers[i] = false
                    break
                }
            }
        }
    }
    
    public var body: some View {
        ScrollView {
            Text("Now let's learn Chords 🎸").font(.title)
            
            VStack {
                HStack {
                    Text("Notes:").foregroundColor(.gray).bold()
                    
                    ForEach(0..<notes.count, id: \.self){ i in
                        SelectableItem(title: notes[i], selected: chordKey == notes[i], action: {
                            chordKey = notes[i]
                            chordNotes = calculateChordNotes(key: chordKey, chordType: chordType)
                        })
                        .transition(transition)
                        .id("note_\(notes[i])")
                    }
                }
                
                HStack {
                    Text("Chord Type:").foregroundColor(.gray).bold()
                    
                    ForEach(0..<chordTypes.count, id: \.self){ i in
                        SelectableItem(title: chordTypes[i], selected: chordType == chordTypes[i], action: {
                            chordType = chordTypes[i]
                        })
                        .transition(transition)
                        .id("chord_\(chordTypes[i])")
                    }
                }.onChange(of: chordType, perform: {_ in
                    if let chord = getChordFromKeyAndType(key: chordKey, chordType: chordType, instrument: instrument) {
                        if chord.chordType == "Minor" {
                            nums[1] = "b3";
                        } else {
                            nums[1] = "3";
                        }
                        chordNotes = calculateChordNotes(key: chordKey, chordType: chordType)
                    }
                })
                
                HStack {
                    Text("Instrument:").foregroundColor(.gray).bold()
                    
                    ForEach(0..<instruments.count, id: \.self){ i in
                        SelectableItem(title: instruments[i], selected: instrument == instruments[i], action: {
                            instrument = instruments[i]
                        })
                        .transition(transition)
                        .id("instrument_\(instruments[i])")
                    }
                }
            }
            
            if let chord = getChordFromKeyAndType(key: chordKey, chordType: chordType, instrument: instrument) {
                Text("\(chordKey) \(chordType)")
                    .font(.system(size: 24))
                    .padding(.vertical, 8)
                    .transition(transition)
                    .id("chord_\(chordKey)_\(chordType)")
                
                Image(uiImage: chord.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .scaledToFit()
                    .frame(maxHeight: 200)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.black, lineWidth: 1))
                    .padding(.horizontal, 36)
                    .padding(.bottom, 8)
                    .transition(transition)
                    .id("image_\(chord.label)_\(instrument)")
                
                VStack {
                    HStack(spacing: 8) {
                        ForEach(0..<nums.count, id: \.self){ num in
                            VStack{ 
                                Text(nums[num])
                                    .foregroundColor(.gray)
                                    .font(.system(size: 14))
                                    .transition(transition)
                                    .id("num_\(nums[num])")
                                
                                Text(chordNotes[(Int(num) ?? 0)])
                                    .font(.system(size: 14))
                                    .transition(transition)
                                    .id("notes_" + chordNotes[(Int(num) ?? 0)])
                            }
                            .frame(width: 24)
                            .padding(.bottom, 4)
                        }
                    }
                    
                    HStack(spacing: 12) {
                        ForEach(0..<chord.formula.count, id: \.self){ i in
                            VStack {
                                Text(chord.formula[i] == 3 ? "W+H" : "W+W")
                                    .transition(transition)
                                    .id("w_h_\(chord.formula[i])")
                            }
                            .frame(width: 34)
                            .padding(.top, 8)
                            //Top border.
                            .overlay(Rectangle().frame(height: 2, alignment: .top).foregroundColor(.gray), alignment: .top)
                        }
                    }
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 8)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray, lineWidth: 1))
                
                Text("About the \(chord.chordType) Chord 🎶")
                    .bold()
                    .font(.title)
                    .padding(.vertical, 8)
                    .transition(transition)
                    .id("chord_" + chord.chordType)
                
                if chord.chordType == "Major" {
                    Text("A major chord has a root, a major third, and a perfect fifth. That means that the first note of \(chord.label) is \(chord.key) and the second note is two whole steps (W+W) ahead of the first note. The note two whole steps ahead of \(chord.key) is \(getIthNoteAfter(note: chord.key, i: 4)). The next note is a whole and a half steps (W+H) ahead. Try to figure out the next note yourself 🎶.")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 20)
                        .transition(transition)
                        .id("chord_detail_" + chord.chordType + "_" + chord.key)
                } 
                else if chord.chordType == "Minor" {
                    Text("A minor chord has a root, a minor third, and a perfect fifth. That means that the first note of \(chord.label) is \(chord.key) and the second note is a whole and a half steps (W+H) ahead of the first note. The note two whole steps ahead of \(chord.key) is \(getIthNoteAfter(note: chord.key, i: 3)). The next note is two whole steps (W+W) ahead. Try to figure out the next note yourself 🎶.")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 20)
                        .transition(transition)
                        .id("chord_detail_" + chord.chordType + "_" + chord.key)
                }
            } else {
                Text("An error occured!")
            }
            
            VStack {
                if buttonClicks == 1 {
                    Text("May I ask you another question? Can you select all the notes for the \(randomChord.key) \(randomChord.chordType) Chord?")
                        .padding(.bottom, 8)
                        .transition(transition)
                        .id("question")
                    
                    HStack {
                        ForEach(0..<notes.count, id: \.self){ i in
                            SelectableItem(title: notes[i], selected: answers[i], action: {
                                setAnswer(index: i)
                            })
                            .transition(transition)
                            .id("answer_\(notes[i])")
                        }
                    }.padding(.bottom, 4)
                }
                if incorrectAnswer {
                    Text("Please try again 😔")
                        .padding(.bottom, 8)
                }
                if buttonClicks < 2 {
                    Button("Continue") {
                        if buttonClicks == 0 {
                            buttonClicks += 1
                        }
                        else if buttonClicks == 1 {
                            let randomChordNotes = calculateChordNotes(key: randomChord.key, chordType: randomChord.chordType)
                            
                            for i in 0..<randomChordNotes.count {
                                let noteIndex = getNoteIndex(note: randomChordNotes[i]) ?? 0
                                if !answers[noteIndex] {
                                    incorrectAnswer = true
                                    return
                                }
                            }
                            
                            buttonClicks = 2
                            incorrectAnswer = false
                        } 
                    }
                    .font(.title)
                    .transition(transition)
                    .id("continue1")
                }
                if buttonClicks == 2 {
                    Text("Yay 🎉, you got it right!")
                        .padding(.vertical, 8)
                        .transition(transition)
                        .id("correct")
                    
                    NavigationLink(destination: SuccessView()){
                        Text("Continue")
                            .font(.title)
                    }
                    .transition(transition)
                    .id("continue2")
                }
            }.padding(.horizontal, 16)
        }
    }
}
