
import SwiftUI
import UIKit

public let chordTypes = ["Major", "Minor"]

public class Chord: ObservableObject, Identifiable, Equatable {
    public let id = UUID()
    public init(image: UIImage, label: String, chordType: String, key: String, formula: [Int]){
        self.image = image
        self.label = label
        self.chordType = chordType
        self.key = key
        self.formula = formula
    }
    
    public static func == (lhs: Chord, rhs: Chord) -> Bool {
        return lhs.label == rhs.label
    }
    
    @Published var image: UIImage
    @Published var label: String
    @Published var chordType: String
    @Published var key: String
    @Published var formula: [Int]
}


public struct GuitarChords {
    static let majorFormula = [4, 3]
    static let minorFormula = [3, 4]
    
    public static let chords = [
        aMajor,
        aMinor,
        aSMajor, 
        aSMinor,
        bMajor,
        bMinor,
        cMajor,
        cMinor,
        cSMajor, 
        cSMinor,
        dMajor,
        dMinor,
        dSMajor,
        dSMinor,
        eMajor,
        eMinor,
        fMajor,
        fMinor,
        fSMajor,
        fSMinor,
        gMajor,
        gMinor,
        gSMajor,
        gSMinor
    ]
    public static let aMajor = Chord(image: #imageLiteral(resourceName: "guitar-A-a-n-l-h-x-0-2-2-2-0.jpg"), label: "A Major", chordType: chordTypes[0], key: "A", formula: majorFormula)
    public static let aMinor = Chord(image: #imageLiteral(resourceName: "guitar-Am-a-n-l-h-x-0-2-2-1-0.jpg"), label: "A Minor", chordType: chordTypes[1], key: "A", formula: minorFormula)
    public static let aSMajor = Chord(image: #imageLiteral(resourceName: "guitar-As-a-sharp-l-h-6-8-8-7-6-6.jpg"), label: "A# Major", chordType: chordTypes[0], key: "A#", formula: majorFormula)
    public static let aSMinor = Chord(image: #imageLiteral(resourceName: "guitar-Asm-a-sharp-l-h-6-8-8-6-6-6.jpg"), label: "A# Minor", chordType: chordTypes[1], key: "A#", formula: minorFormula)
    public static let bMajor = Chord(image: #imageLiteral(resourceName: "guitar-B-b-n-l-h-x-2-4-4-4-2.jpg"), label: "B Major", chordType: chordTypes[0], key: "B", formula: majorFormula)
    public static let bMinor = Chord(image: #imageLiteral(resourceName: "guitar-Bm-b-n-l-h-7-9-9-7-7-7.jpg"), label: "B Minor", chordType: chordTypes[1], key: "B", formula: minorFormula)
    public static let cMajor = Chord(image: #imageLiteral(resourceName: "guitar-C-c-n-l-h-x-3-2-0-1-0.jpg"), label: "C Major", chordType: chordTypes[0], key: "C", formula: majorFormula)
    public static let cMinor = Chord(image: #imageLiteral(resourceName: "guitar-Cm-c-n-l-h-x-3-5-5-4-3.jpg"), label: "C Minor", chordType: chordTypes[1], key: "C", formula: minorFormula)
    public static let cSMajor = Chord(image: #imageLiteral(resourceName: "guitar-Cs-c-sharp-l-h-x-4-6-6-6-4.jpg"), label: "C# Major", chordType: chordTypes[0], key: "C#", formula: majorFormula)
    public static let cSMinor = Chord(image: #imageLiteral(resourceName: "guitar-Csm-c-sharp-l-h-x-4-6-6-5-4.jpg"), label: "C# Minor", chordType: chordTypes[1], key: "C#", formula: minorFormula)
    public static let dMajor = Chord(image: #imageLiteral(resourceName: "guitar-D-d-n-l-h-x-x-0-2-3-2.jpg"), label: "D Major", chordType: chordTypes[0], key: "D", formula: majorFormula)
    public static let dMinor = Chord(image: #imageLiteral(resourceName: "guitar-Dm-d-n-l-h-x-x-0-2-3-1.jpg"), label: "D Minor", chordType: chordTypes[1], key: "D", formula: minorFormula)
    public static let dSMajor = Chord(image: #imageLiteral(resourceName: "guitar-Ds-d-sharp-l-h-x-x-1-3-4-3.jpg"), label: "D# Major", chordType: chordTypes[0], key: "D#", formula: majorFormula)
    public static let dSMinor = Chord(image: #imageLiteral(resourceName: "guitar-Dsm-d-sharp-l-h-11-13-13-11-11-11.jpg"), label: "D# Minor", chordType: chordTypes[1], key: "D#", formula: minorFormula)
    public static let eMajor = Chord(image: #imageLiteral(resourceName: "guitar-E-e-n-l-h-0-2-2-1-0-0.jpg"), label: "E Major", chordType: chordTypes[0], key: "E", formula: majorFormula)
    public static let eMinor = Chord(image: #imageLiteral(resourceName: "guitar-Em-e-n-l-h-0-2-2-0-0-0.jpg"), label: "E Minor", chordType: chordTypes[1], key: "E", formula: minorFormula)
    public static let fMajor = Chord(image: #imageLiteral(resourceName: "guitar-F-f-n-l-h-1-3-3-2-1-1.jpg"), label: "F Major", chordType: chordTypes[0], key: "F", formula: majorFormula)
    public static let fMinor = Chord(image: #imageLiteral(resourceName: "guitar-Fm-f-n-l-h-1-3-3-1-1-1.jpg"), label: "F Minor", chordType: chordTypes[1], key: "F", formula: minorFormula)
    public static let fSMajor = Chord(image: #imageLiteral(resourceName: "guitar-Fs-f-sharp-l-h-2-4-4-3-2-2.jpg"), label: "F# Major", chordType: chordTypes[0], key: "F#", formula: majorFormula)
    public static let fSMinor = Chord(image: #imageLiteral(resourceName: "guitar-Fsm-f-sharp-l-h-2-4-4-2-2-2.jpg"), label: "F# Minor", chordType: chordTypes[1], key: "F#", formula: minorFormula)
    public static let gMajor = Chord(image: #imageLiteral(resourceName: "guitar-G-g-n-l-h-3-2-0-0-0-3.jpg"), label: "G Major", chordType: chordTypes[0], key: "G", formula: majorFormula)
    public static let gMinor = Chord(image: #imageLiteral(resourceName: "guitar-Gm-g-n-l-h-x-10-12-12-11-10.jpg"), label: "G Minor", chordType: chordTypes[1], key: "G", formula: minorFormula)
    public static let gSMajor = Chord(image: #imageLiteral(resourceName: "guitar-Gs-g-sharp-l-h-4-6-6-5-4-4.jpg"), label: "G# Major", chordType: chordTypes[0], key: "G#", formula: majorFormula)
    public static let gSMinor = Chord(image: #imageLiteral(resourceName: "guitar-Gsm-g-sharp-l-h-x-11-13-13-12-11.jpg"), label: "G# Minor", chordType: chordTypes[1], key: "G#", formula: minorFormula)
} 


public struct PianoChords {
    static let majorFormula = [4, 3]
    static let minorFormula = [3, 4]
    
    public static let chords = [
        aMajor,
        aMinor,
        aSMajor, 
        aSMinor,
        bMajor,
        bMinor,
        cMajor,
        cMinor,
        cSMajor, 
        cSMinor,
        dMajor,
        dMinor,
        dSMajor,
        dSMinor,
        eMajor,
        eMinor,
        fMajor,
        fMinor,
        fSMajor,
        fSMinor,
        gMajor,
        gMinor,
        gSMajor,
        gSMinor
    ]
    public static let aMajor = Chord(image: #imageLiteral(resourceName: "piano-A-a-n-l-a-cs-e.jpg"), label: "A Major", chordType: chordTypes[0], key: "A", formula: majorFormula)
    public static let aMinor = Chord(image: #imageLiteral(resourceName: "piano-Am-a-n-l-a-c-e.jpg"), label: "A Minor", chordType: chordTypes[1], key: "A", formula: minorFormula)
    public static let aSMajor = Chord(image: #imageLiteral(resourceName: "piano-As-a-sharp-l-as-d-f.jpg"), label: "A# Major", chordType: chordTypes[0], key: "A#", formula: majorFormula)
    public static let aSMinor = Chord(image: #imageLiteral(resourceName: "piano-Asm-a-sharp-l-as-cs-f.jpg"), label: "A# Minor", chordType: chordTypes[1], key: "A#", formula: minorFormula)
    public static let bMajor = Chord(image: #imageLiteral(resourceName: "piano-B-b-n-l-b-ds-fs.jpg"), label: "B Major", chordType: chordTypes[0], key: "B", formula: majorFormula)
    public static let bMinor = Chord(image: #imageLiteral(resourceName: "piano-Bm-b-n-l-b-d-fs.jpg"), label: "B Minor", chordType: chordTypes[1], key: "B", formula: minorFormula)
    public static let cMajor = Chord(image: #imageLiteral(resourceName: "piano-C-c-n-l-c-e-g.jpg"), label: "C Major", chordType: chordTypes[0], key: "C", formula: majorFormula)
    public static let cMinor = Chord(image: #imageLiteral(resourceName: "piano-Cm-c-n-l-c-ds-g.jpg"), label: "C Minor", chordType: chordTypes[1], key: "C", formula: minorFormula)
    public static let cSMajor = Chord(image: #imageLiteral(resourceName: "piano-Cs-c-sharp-l-cs-f-gs.jpg"), label: "C# Major", chordType: chordTypes[0], key: "C#", formula: majorFormula)
    public static let cSMinor = Chord(image: #imageLiteral(resourceName: "piano-Csm-c-sharp-l-cs-e-gs.jpg"), label: "C# Minor", chordType: chordTypes[1], key: "C#", formula: minorFormula)
    public static let dMajor = Chord(image: #imageLiteral(resourceName: "piano-D-d-n-l-d-fs-a.jpg"), label: "D Major", chordType: chordTypes[0], key: "D", formula: majorFormula)
    public static let dMinor = Chord(image: #imageLiteral(resourceName: "piano-Dm-d-n-l-d-f-a.jpg"), label: "D Minor", chordType: chordTypes[1], key: "D", formula: minorFormula)
    public static let dSMajor = Chord(image: #imageLiteral(resourceName: "piano-Ds-d-sharp-l-ds-g-as.jpg"), label: "D# Major", chordType: chordTypes[0], key: "D#", formula: majorFormula)
    public static let dSMinor = Chord(image: #imageLiteral(resourceName: "piano-Dsm-d-sharp-l-ds-fs-as.jpg"), label: "D# Minor", chordType: chordTypes[1], key: "D#", formula: minorFormula)
    public static let eMajor = Chord(image: #imageLiteral(resourceName: "piano-E-e-n-l-e-gs-b.jpg"), label: "E Major", chordType: chordTypes[0], key: "E", formula: majorFormula)
    public static let eMinor = Chord(image: #imageLiteral(resourceName: "piano-Em-e-n-l-e-g-b.jpg"), label: "E Minor", chordType: chordTypes[1], key: "E", formula: minorFormula)
    public static let fMajor = Chord(image: #imageLiteral(resourceName: "piano-F-f-n-l-f-a-c.jpg"), label: "F Major", chordType: chordTypes[0], key: "F", formula: majorFormula)
    public static let fMinor = Chord(image: #imageLiteral(resourceName: "piano-Fm-f-n-l-f-gs-c.jpg"), label: "F Minor", chordType: chordTypes[1], key: "F", formula: minorFormula)
    public static let fSMajor = Chord(image: #imageLiteral(resourceName: "piano-Fs-f-sharp-l-fs-as-cs.jpg"), label: "F# Major", chordType: chordTypes[0], key: "F#", formula: majorFormula)
    public static let fSMinor = Chord(image: #imageLiteral(resourceName: "piano-Fsm-f-sharp-l-fs-a-cs.jpg"), label: "F# Minor", chordType: chordTypes[1], key: "F#", formula: minorFormula)
    public static let gMajor = Chord(image: #imageLiteral(resourceName: "piano-G-g-n-l-g-b-d.jpg"), label: "G Major", chordType: chordTypes[0], key: "G", formula: majorFormula)
    public static let gMinor = Chord(image: #imageLiteral(resourceName: "piano-Gm-g-n-l-g-as-d.jpg"), label: "G Minor", chordType: chordTypes[1], key: "G", formula: minorFormula)
    public static let gSMajor = Chord(image: #imageLiteral(resourceName: "piano-Gs-g-sharp-l-gs-c-ds.jpg"), label: "G# Major", chordType: chordTypes[0], key: "G#", formula: majorFormula)
    public static let gSMinor = Chord(image: #imageLiteral(resourceName: "piano-Gsm-g-sharp-l-gs-b-ds.jpg"), label: "G# Minor", chordType: chordTypes[1], key: "G#", formula: minorFormula)
} 
