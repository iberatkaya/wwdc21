


import SwiftUI

public struct ScalesView: View {
    //Make the struct public.
    public init (){}
    
    @State var incorrectAnswer = false
    
    @State var scaleKey: String = GuitarScales.scales[0].key
    @State var scaleType: String = GuitarScales.scales[0].scaleType
    
    @State var nums = ["1", "2", "3", "4", "5", "6", "7"];
    
    @State var scaleNotes = ["A", "B", "C#", "D", "E","F#","G#"]
    
    @State var answers = notes.map({ _ in false })
    
    @State var instruments = ["Guitar", "Piano"]
    
    @State var buttonClicks = 0

    @State var instrument = "Guitar"
    
    @State var randomScale = GuitarScales.scales[Int.random(in: 0..<GuitarScales.scales.count)]
    
    let transition = AnyTransition.opacity.animation(.easeInOut(duration: 0.5))
    
    
    func setAnswer(index: Int) {
        answers[index] = !answers[index]
        var trueCount = 0
        for i in 0..<answers.count {
            if answers[i] {
                trueCount += 1
            }
        }
        if trueCount > 7 {
            for i in 0..<answers.count {
                if answers[i] {
                    answers[i] = false
                    break
                }
            }
        }
    }
    
    public var body: some View {
        ScrollView {
            Text("Now let's learn Music Scales 🎼.").font(.title)

            VStack {
                HStack {
                    Text("Notes:").foregroundColor(.gray).bold()
                
                    ForEach(0..<notes.count, id: \.self){ i in
                        SelectableItem(title: notes[i], selected: scaleKey == notes[i], action: {
                            scaleKey = notes[i]
                        })
                        .transition(transition)
                        .id("note_\(notes[i])")
                    }
                }
                
                HStack {
                    Text("Scales:").foregroundColor(.gray).bold()
                    
                    ForEach(0..<scaleTypes.count, id: \.self){ i in
                        SelectableItem(title: scaleTypes[i], selected: scaleType == scaleTypes[i], action: {
                            scaleType = scaleTypes[i]
                        })
                        .transition(transition)
                        .id("scales_\(scaleTypes[i])")
                    }
                }.onChange(of: scaleType, perform: { _ in
                        if let scale = getScaleFromKeyAndType(key: scaleKey, scaleType: scaleType, instrument: instrument) {
                            if scale.scaleType == "Minor" {
                                nums[2] = "b3";
                                nums[5] = "b6";
                                nums[6] = "b7";
                            } else {
                                nums[2] = "3";
                                nums[5] = "6";
                                nums[6] = "7";
                            }
                            scaleNotes = calculateScaleNotes(key: scaleKey, scaleType: scaleType)
                        }
                    })
                
                HStack {
                    Text("Instrument:").foregroundColor(.gray).bold()

                    ForEach(0..<instruments.count, id: \.self){ i in
                        SelectableItem(title: instruments[i], selected: instrument == instruments[i], action: {
                            instrument = instruments[i]
                        })
                        .transition(transition)
                        .id("instrument_\(instruments[i])")
                    }
                }
            }.padding(.bottom, 6)
            
            if let scale = getScaleFromKeyAndType(key: scaleKey, scaleType: scaleType, instrument: instrument) {
                Text("\(scaleKey) \(scaleType)")
                    .font(.system(size: 24))
                    .padding(.vertical, 8)
                    .transition(transition)
                    .id("scale_\(scaleKey)_\(scaleType)")
                
                Image(uiImage: scale.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .scaledToFit()
                    .frame(maxHeight: 240)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.black, lineWidth: 1))
                    .padding(.horizontal, 24)
                    .padding(.bottom, 8)
                    .transition(transition)
                    .id("image_\(scale.label)_\(instrument)")
                
                VStack {
                    HStack {
                        ForEach(0..<nums.count, id: \.self){ num in
                            VStack{ 
                                Text(nums[num])
                                    .foregroundColor(.gray)
                                    .font(.system(size: 16))
                                    .transition(transition)
                                    .id("num_\(nums[num])")
                                
                                Text(scaleNotes[(Int(num) ?? 0)])
                                    .font(.system(size: 14))
                                    .transition(transition)
                                    .id("notes_" + scaleNotes[(Int(num) ?? 0)])
                            }
                            .padding(.bottom, 4)
                            .frame(width: 30)
                        }
                    }
                    
                    HStack {
                        ForEach(0..<scale.formula.count, id: \.self){ i in
                            VStack {
                                Text(scale.formula[i] == 2 ? "W" : "H")
                                    .transition(transition)
                                    .id("w_h_\(scale.formula[i])")
                            }
                            .frame(width: 30)
                            .padding(.top, 8)
                            //Top border.
                            .overlay(Rectangle().frame(height: 2, alignment: .top).foregroundColor(.gray), alignment: .top)
                        }
                    }
                }
                .padding(.vertical, 12)
                .padding(.horizontal, 8)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray, lineWidth: 1))
                
                Text("About the \(scale.scaleType) Scale 🎼")
                    .bold()
                    .font(.title)
                    .padding(.vertical, 8)
                    .transition(transition)
                    .id("scale_" + scale.scaleType)
                
                if scale.scaleType == "Major" {
                    Text("A Major Scale follow this pattern of whole steps and half steps: W W H W W W H (whole, whole, half, whole, whole, whole, half). That means that the first note of \(scale.label) is \(scale.key) and the second note is one whole step ahead of the first note. The note a whole step ahead of \(scale.key) is \(getIthNoteAfter(note: scale.key, i: 2)). The third note is a whole step ahead of \(getIthNoteAfter(note: scale.key, i: 2)). That note is \(getIthNoteAfter(note: scale.key, i: 4)). Try to figure out the rest of the notes yourself 🎶.")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 20)
                        .transition(transition)
                        .id("scale_detail_" + scale.scaleType + "_" + scale.key)
                } 
                else if scale.scaleType == "Minor" {
                    Text("A Minor Scale uses this pattern of whole steps and half steps: W H W W H W W (whole, half, whole, whole, half, whole, whole). That means that the first note of \(scale.label) is \(scale.key) and the second note is one whole step ahead of the first note. The note a whole step ahead of \(scale.key) is \(getIthNoteAfter(note: scale.key, i: 2)). The third note is a half step ahead of \(getIthNoteAfter(note: scale.key, i: 2)). That note is \(getIthNoteAfter(note: scale.key, i: 3)). Try to figure out the rest of the notes yourself 🎶.")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 20)
                        .transition(transition)
                        .id("scale_detail_" + scale.scaleType + "_" + scale.key)
                }
            } else {
                Text("An error occured!")
            }
            VStack {
                if buttonClicks == 1 {
                    Text("May I ask you a question? Can you select all the notes for the \(randomScale.key) \(randomScale.scaleType) Scale?")
                        .padding(.bottom, 8)
                        .transition(transition)
                        .id("question")
                    
                    HStack {
                        ForEach(0..<notes.count, id: \.self){ i in
                            SelectableItem(title: notes[i], selected: answers[i], action: {
                                setAnswer(index: i)
                            })
                            .transition(transition)
                            .id("answer_\(notes[i])")
                        }
                    }.padding(.bottom, 4)
                }
                if incorrectAnswer {
                    Text("Please try again 😔")
                        .padding(.bottom, 8)
                        .transition(transition)
                        .id("incorrect")
                }
                
                if buttonClicks < 2 {
                    Button("Continue") {
                        if buttonClicks == 0 {
                            buttonClicks += 1
                        }
                        else if buttonClicks == 1 {
                            let randomScaleNotes = calculateScaleNotes(key: randomScale.key, scaleType: randomScale.scaleType)

                            for i in 0..<randomScaleNotes.count {
                                let noteIndex = getNoteIndex(note: randomScaleNotes[i]) ?? 0
                                if !answers[noteIndex] {
                                    incorrectAnswer = true
                                    return
                                }
                            }
                            
                            buttonClicks = 2
                            incorrectAnswer = false
                        } 
                    }
                    .font(.title)
                    .transition(transition)
                    .id("continue1")
                }
                if buttonClicks == 2 {
                    Text("Yay 🎉, you got it right!").padding(.vertical, 8)
                        .transition(transition)
                        .id("correct")
                    NavigationLink(destination: ChordsView()){
                        Text("Continue")
                    }
                    .font(.title)
                    .transition(transition)
                    .id("continue2")
                }
            }.padding(.horizontal, 16)
        }
    }
}
