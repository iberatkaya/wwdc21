import SwiftUI

public struct NotesView: View {
    //Make the struct public.
    public init(){}
    
    @State var buttonClicks = 0
    
    @State var randomNoteIndex = Int.random(in: 0..<notes.count)
    
    @State var randomHalfWhole = ["W", "H"][Int.random(in: 0...1)]
    
    @State var incorrectAnswer = false
    
    @State var halfOrWhole = [false, false]
    
    let transition = AnyTransition.opacity.animation(.easeInOut(duration: 0.5))
    
    func setAnswer(index: Int) {
        for i in 0..<halfOrWhole.count {
            if i != index {
                halfOrWhole[i] = false
            }
        }
        halfOrWhole[index] = !halfOrWhole[index]
    }
    
    public var body: some View {
        ScrollView {
            Text("Now let's learn Musical Notes 🎼.")
                .font(.title)
                .padding(.bottom, 8)
            
            Text("We have 12 notes: A A# B C C# D D# E F F# G G#")
                .fixedSize(horizontal: false, vertical: true)
                .font(.system(size: 18))
                .padding(.bottom, 4)
            
            Text("Each adjacent two notes has a half step (H) difference and two half steps make a whole step (W). A half step is also called a semitone. For example, let's find the note a whole step ahead of G. G is the 11th note of the 12 notes. Adding 2 to 11 gives us 13. Since there are 12 notes, we need to calculate 13 modulo 12. 13 mod 12 is equal to 1, and that note is A. So A is a whole step ahead of G.")
                .fixedSize(horizontal: false, vertical: true)
                .font(.system(size: 16))
                .padding(.horizontal, 20)
                .padding(.bottom, 12)
            
            VStack {
                HStack(spacing: 10) {
                    ForEach(0..<notes.count, id: \.self){ i in
                        Text(notes[i])
                            .bold()
                            .font(.system(size: 18))
                            .frame(width: 28)
                    }
                }.padding(.bottom, 4)
                
                HStack(spacing: 11) {
                    ForEach(0..<notes.count-1, id: \.self){ i in
                        VStack {
                            Text("H")
                                .transition(transition)
                                .id("h")
                        }
                        .frame(width: 28)
                        .padding(.top, 8)
                        //Top border.
                        .overlay(Rectangle().frame(height: 2, alignment: .top).foregroundColor(.gray), alignment: .top)
                    }
                }.padding(.bottom, 8)
                
                HStack(spacing: 18) {
                    ForEach(0..<notes.count/2, id: \.self){ i in
                        if i == notes.count/2 - 1 {
                            Spacer().frame(width: 44)
                        }
                        else {
                            VStack {
                                Text("W")
                                    .transition(transition)
                                    .id("W")
                            }
                            .frame(width: 60)
                            .padding(.top, 8)
                            //Top border.
                            .overlay(Rectangle().frame(height: 2, alignment: .top).foregroundColor(.gray), alignment: .top)
                        }
                    }
                }
                .padding(.leading, 20)
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 8)
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray, lineWidth: 1))
            
            Text("Examples:")
                .font(.system(size: 18))
                .padding(.bottom, 4)
            Text("A - A# -> Half step\nG# - A# -> Whole step")
                .fixedSize(horizontal: false, vertical: true)
                .font(.system(size: 16))
                .padding(.bottom, 8)
            
            VStack {
                if buttonClicks == 1 {
                    Text("May I ask you a question? What is the step difference between \(notes[randomNoteIndex]) and \(notes[(randomNoteIndex + (randomHalfWhole == "H" ? 1 : 2)) % notes.count])?")
                        .font(.system(size: 16))
                        .padding(.bottom, 8)
                        .transition(transition)
                        .id("question")
                    
                    HStack(alignment: .top) {
                        Spacer()
                        
                        Text("\(notes[randomNoteIndex]) - \(notes[(randomNoteIndex + (randomHalfWhole == "H" ? 1 : 2)) % notes.count]) ->")
                            .font(.system(size: 16))
                            .padding(.bottom, 8)
                        
                        SelectableItem(title: "Half", selected: halfOrWhole[0], action: {
                            setAnswer(index: 0)
                        })
                        
                        SelectableItem(title: "Whole", selected: halfOrWhole[1], action: {
                            setAnswer(index: 1) 
                        })
                        
                        Spacer()
                    }
                    .transition(transition)
                    .id("answer")
                }
                if incorrectAnswer {
                    Text("Please try again 😔").padding(.vertical, 8)
                }
                if buttonClicks < 2 {
                    Button("Continue") {
                        if buttonClicks == 0 {
                            buttonClicks += 1
                        }
                        else if buttonClicks == 1 {
                            if (halfOrWhole[0] && randomHalfWhole == "H") || (halfOrWhole[1] && randomHalfWhole == "W")  {
                                buttonClicks = 2
                                incorrectAnswer = false
                            }
                            else {
                                incorrectAnswer = true
                            }
                        } 
                    }
                    .font(.title)
                    .transition(transition)
                    .id("continue1")
                }
                if buttonClicks == 2 {
                    Text("Yay 🎉, you got it right!")
                        .padding(.vertical, 8)
                        .transition(transition)
                        .id("correct")
                    
                    NavigationLink(destination: ScalesView()){
                        Text("Continue")
                            .font(.title)
                    }
                    .transition(transition)
                    .id("continue2")
                }
            }.padding(.vertical, 8)
        }.padding(.horizontal, 16)
    }
}
