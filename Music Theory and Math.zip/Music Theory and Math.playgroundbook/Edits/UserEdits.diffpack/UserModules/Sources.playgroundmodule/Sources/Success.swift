
import SwiftUI

public struct SuccessView: View {
    //Make the struct public.
    public init (){}

    public var body: some View {
        VStack {
            Image(uiImage: #imageLiteral(resourceName: "congrats.png"))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100)
                .padding(.bottom, 12)
            
            VStack {
                Text("Congratulations!")
                    .font(.title)
                    .bold()
                Text("You have learned about Music Theory and the simple Math behind it.")
                    .font(.title)
            }
            .multilineTextAlignment(.center)
            .padding(.bottom, 12)
            .padding(.horizontal, 16)
            
        }
    }
}
