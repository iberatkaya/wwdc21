import SwiftUI
import PlaygroundSupport

public struct HomeView: View {
    //Make the struct public.
    public init (){}
    
    public var body: some View {
        NavigationView {
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "happy.png"))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100)
                    .padding(.bottom, 12)
                
                Text("Music Theory and Math")
                    .font(.title)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 12)
                    .padding(.horizontal, 16)
                
                Text("Hello, I am Ibrahim Berat Kaya. Welcome to my Playground.\nLet's learn about Music Theory and Math!")
                    .font(.system(size: 20))
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 12)
                    .padding(.horizontal, 16)
                
                NavigationLink(destination: NotesView(), label: {
                    Text("Continue")
                        .font(.title)
                }) 
            }.frame(alignment: .center)
        }.navigationViewStyle(StackNavigationViewStyle())
    }
}
