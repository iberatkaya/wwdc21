///Get a `Scale` from a `key`, `type`, and `instrument`. 
public func getScaleFromKeyAndType(key: String, scaleType: String, instrument: String = "Guitar") -> Scale? {
    if instrument == "Piano" {
        return PianoScales.scales.first(where: {$0.key == key && $0.scaleType == scaleType})
    }
    return GuitarScales.scales.first(where: {$0.key == key && $0.scaleType == scaleType})
}

///Get a Chord from a `key`, `type`, and `instrument`. 
public func getChordFromKeyAndType(key: String, chordType: String, instrument: String = "Guitar") -> Chord? {
    if instrument == "Piano" {
        return PianoChords.chords.first(where: {$0.key == key && $0.chordType == chordType})
    }
    return GuitarChords.chords.first(where: {$0.key == key && $0.chordType == chordType})
}

///Calculate the notes of a `Chord` from a `key` and `scaleType`.
func calculateChordNotes(key: String, chordType: String) -> [String] {
    if let chord = getChordFromKeyAndType(key: key, chordType: chordType), var index = getNoteIndex(note: chord.key) {
        var myNotes: [String] = [chord.key]
        for i in chord.formula {
            myNotes.append(notes[(index + i) % 12])
            index += i
        }
        return myNotes
    }
    return []
}

///Calculate the notes of a `Scale` from a `key` and `scaleType`.
func calculateScaleNotes(key: String, scaleType: String) -> [String] {
    if let scale = getScaleFromKeyAndType(key: key, scaleType: scaleType), var index = getNoteIndex(note: scale.key) {
        var myNotes: [String] = [scale.key]
        for i in scale.formula {
            myNotes.append(notes[(index + i) % 12])
            index += i
        }
        return myNotes
    }
    return []
}

///Get the index of a `note`.
func getNoteIndex(note: String) -> Int? {
    return notes.firstIndex(where: {$0 == note})
}

///Get the `i`th note after `note`.
func getIthNoteAfter(note: String, i: Int) -> String {
    return notes[((getNoteIndex(note: note) ?? 0) + i) % notes.count]
}
